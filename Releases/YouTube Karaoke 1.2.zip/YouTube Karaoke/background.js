chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
	console.log(tab.url);
	if (tab.url.indexOf("www.youtube.com/watch") == -1) {
		console.log("Not video page - 2");
		return;
	}
	if (changeInfo.url !== undefined && changeInfo.url.indexOf("www.youtube.com/watch") == -1) {
			console.log("Not video page");
			return;
		}
	if (changeInfo.status != "complete") {
		console.log("Not finished loading");
		return;
	}
	console.log("Finished loading, inserting code");
	chrome.tabs.executeScript(tabId, { file: 'insert.js' });
});

// Check whether new version is installed
chrome.runtime.onInstalled.addListener(function(details){
    if(details.reason == "install"){
        console.log("First time install, show playlist");
		// new tab with youtube playlist
		chrome.tabs.create({url: "https://www.youtube.com/playlist?list=PLniGrGQu6vfniYxthYMMRChuN1pacWbNX"});
    }else if(details.reason == "update"){
        var thisVersion = chrome.runtime.getManifest().version;
        console.log("Updated from " + details.previousVersion + " to " + thisVersion + "!");
    }
});
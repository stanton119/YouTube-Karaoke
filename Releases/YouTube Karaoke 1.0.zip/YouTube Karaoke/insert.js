var mediaElement;
var parentNode;
var karaokeButton;
var karaokeState = 0;	// assume off
var paused;			// paused state
var context, audioSource, splitter, gainL, gainR;
var FilterNotch, FilterBand, gainFilter;
var FilterLP1, FilterHP1, FilterLP2, FilterHP2;
var filtersOn = 0;
var filterType = 2;

// youtube reuses same video container, so no need to store karaokeState and tabID between sessions

function SetupButton(){
	// **** check whether flash or html5 **** //
	// check for valid YouTube URL
	if (window.location.href.indexOf("www.youtube.com/watch") == -1) {
		console.log("Not video page");
		return;
	}
	
	// get first video element
	mediaElement = document.getElementsByClassName('html5-main-video')[0];
	
	// check for html5/flash
	// if flash, append html5=1 to url, reload
	if (typeof mediaElement == "undefined") {
		// no html5, reload with tag
		if (window.location.href.toLowerCase().indexOf("html5=1") == -1){
			console.log("Refreshing to HTML5 page");
			window.location.href = window.location.href + '&html5=1';
		}
		// still using flash - ignore
		console.log("Still on flash - ignore, only works with html5");
		return;
	}
		
	// setup parent node
	parentNode = mediaElement.parentNode;
	
	
	// **** add player button **** //
	
	// check for button already
	if (document.getElementsByClassName('ytp-button ytp-button-watch-later ytp-button-karaoke').length>0){
		console.log("Button already added");
		return;
	}
	
	// get last player button class
	// youtube class: html5-main-video
	console.log("Getting last button");
	var Buttons = document.getElementsByClassName('ytp-button ytp-button-watch-later');
	var playButton = Buttons[Buttons.length - 1];
	
	// create karaokeButton
	console.log("cloning last button");
	karaokeButton = playButton.cloneNode(true);
	karaokeButton.className = "ytp-button ytp-button-watch-later ytp-button-karaoke";
	
	// add node
	playButton.parentNode.appendChild( karaokeButton );
	console.log("Added karaoke button");
	
	// setup audio routing
	SetupFilter();
	
	karaokeState = 1;
	karaokeStateChange();
	
	// add listener to button
	karaokeButton.addEventListener('click', karaokeStateChange, false);
	karaokeButton.addEventListener('mouseover', karaokeStateOver, false);
	karaokeButton.addEventListener('mouseout', karaokeStateOut, false);
}

function karaokeStateOver()
{
	// add underneath id:movie_player, new child
	var movPlayer = document.getElementById('movie_player');
	// find caption left spacing	
	var leftDist = karaokeButton.getBoundingClientRect().left - movPlayer.getBoundingClientRect().left + 15;
	
	// add caption box to DOM
	var html = '<div class="ytp-tooltip" style="left: ' + leftDist + 'px; top: 363px; display: block;"><div class="ytp-tooltip-body" style="left: -25.5px;"><span class="ytp-text-tooltip">Karaoke</span></div><div class="ytp-tooltip-arrow"></div></div>';
	
	var div = document.createElement('div');
	div.innerHTML = html;
	while (div.children.length > 0) {
		movPlayer.appendChild(div.children[0]);
	}
}

function karaokeStateOut()
{  
	// remove caption box
	var tooltips = document.getElementsByClassName('ytp-tooltip');
	for (var i=0;i<tooltips.length;i++)
	{ 
		tooltips[i].parentNode.removeChild(tooltips[i]);
	}
}

function karaokeStateChange(){
	
	// turn on/off filters
	if (karaokeState==0){
		console.log("Removing vocals");
		audioSource.disconnect(0);
		if (filtersOn){
			// filter type
			if (filterType==0){
				audioSource.connect(FilterNotch);
				audioSource.connect(FilterBand);
			} else if (filterType==1){
				audioSource.connect(FilterBand);
			} else if (filterType==2){
				audioSource.connect(FilterLP1);
				audioSource.connect(FilterLP2);
			}
		} else {
			audioSource.connect(splitter);
		}
		
		karaokeState = 1;
		karaokeButton.className = "ytp-button ytp-button-watch-later ytp-button-karaoke ytp-button-karaoke-on";
	} else {
		console.log("Adding in vocals");
		audioSource.disconnect(0);
		audioSource.connect(context.destination);
		
		karaokeState = 0;
		karaokeButton.className = "ytp-button ytp-button-watch-later ytp-button-karaoke";
	}
}

function SetupFilter(){
	// setup audio routing
	try {
		// Fix up for prefixing
	    window.AudioContext = window.AudioContext||window.webkitAudioContext;
	    context = new AudioContext();
		
		audioSource = context.createMediaElementSource(mediaElement);
		
		// phase inversion filter
		// input -> splitter
		// output -> destination
		splitter = context.createChannelSplitter(2);
		gainL = context.createGain();
		gainR = context.createGain();
		// Gain stages
		gainL.gain.value = 1;
		gainR.gain.value = -1;
		// reconnect outputs
		splitter.connect(gainL, 0);
		splitter.connect(gainR, 1);
		gainL.connect(context.destination);
		gainR.connect(context.destination);
		
		// Create the bandpass filters
		if (filterType==0){	// if - changes filter type
			// inputs -> FilterNotch & FilterBand
			// outputs -> splitter & destination
			
			// Create the bandpass filters
			FilterNotch = context.createBiquadFilter();
			FilterBand  = context.createBiquadFilter();

			// Notch filter
			FilterNotch.type = 6;
			FilterNotch.frequency.value = 500;	// Set cutoff to 440 HZ
			FilterNotch.Q.value = 0.05; 			// Set cutoff to 440 HZ
			// Bandpass filter
			FilterBand.type = 2;
			FilterBand.frequency.value = 500;	// Set cutoff to 440 HZ
			FilterBand.Q.value = 0.38;			// Set cutoff to 440 HZ

			// connect filters
			FilterNotch.connect(context.destination);
			FilterBand.connect(splitter);
		} else if (filterType==1) {
			// subtract band pass from original
			// inputs -> FilterBand
			// outputs -> splitter & destination
			FilterBand  = context.createBiquadFilter();
			
			// Bandpass filter
			FilterBand.type = 2;
			FilterBand.frequency.value = 500;	// Set cutoff to 440 HZ
			FilterBand.Q.value = 0.38;
			
			// setup band notch filter
			gainFilter = context.createGain();
			gainFilter.gain.value = -1;
			
			// connect filters
			FilterBand.connect(splitter);
			FilterBand.connect(gainFilter);
			gainFilter.connect(context.destination);
			audioSource.connect(context.destination);
		} else if(filterType==2) {
			// create band pass/stop using two biquads
			// inputs -> FilterLP1 & FilterLP2
			// outputs -> splitter & destinations
			
			// filter cutoff frequencies (Hz)
			var f1 = 150;
			var f2 = 1000;
			
			// Bandpass filter = LP + HP
			FilterLP1 = context.createBiquadFilter();
			FilterLP1.type = 0;
			FilterLP1.frequency.value = f2;
			FilterLP1.Q.value = 1;
			FilterHP1 = context.createBiquadFilter();
			FilterHP1.type = 1;
			FilterHP1.frequency.value = f1;
			FilterHP1.Q.value = 1;
			// Bandstop filter = LP + HP
			FilterLP2 = context.createBiquadFilter();
			FilterLP2.type = 0;
			FilterLP2.frequency.value = f1;
			FilterLP2.Q.value = 1;
			FilterHP2 = context.createBiquadFilter();
			FilterHP2.type = 1;
			FilterHP2.frequency.value = f2;
			FilterHP2.Q.value = 1;
			
			// connect filters
			FilterLP1.connect(FilterHP1);
			FilterHP1.connect(splitter);
			FilterLP2.connect(FilterHP2);
			FilterHP2.connect(context.destination);
		}

		audioSource.disconnect(0);
	  }
	  catch(e) {
	    alert('Web Audio API is not supported in this browser');
	  }
}

// **** main **** //
console.log("Loading insert");
SetupButton();
console.log("Finished");

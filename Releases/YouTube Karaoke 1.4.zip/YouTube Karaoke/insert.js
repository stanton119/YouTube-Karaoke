var mediaElement;
var parentNode;
var karaokeButton;
var karaokeState = 0;	// assume off
var paused;			// paused state
var videoTitle;
var context, audioSource, splitter, gainL, gainR;
var FilterNotch, FilterBand, gainFilter;
var FilterLP1, FilterHP1, FilterLP2, FilterHP2;
var FilterLP3, FilterHP3, FilterLP4, FilterHP4;
var filtersOn = 1;
var filterType = 3;
var lyricsShown = 0;

// youtube reuses same video container, so no need to store karaokeState and tabID between sessions

function SetupButton(){
	// **** check whether flash or html5 **** //
	// check for valid YouTube URL
	if (window.location.href.indexOf("www.youtube.com/watch") == -1) {
		console.log("Not video page");
		return;
	}
	
	// get first video element
	mediaElement = document.getElementsByClassName('html5-main-video')[0];
	
	// check for html5/flash
	// if flash, append html5=1 to url, reload
	if (typeof mediaElement == "undefined") {
		// no html5, reload with tag
		if (window.location.href.toLowerCase().indexOf("html5=1") == -1){
			console.log("Refreshing to HTML5 page");
			window.location.href = window.location.href + '&html5=1';
		}
		// still using flash - ignore
		console.log("Still on flash - ignore, only works with html5");
		return;
	}
		
	// setup parent node
	parentNode = mediaElement.parentNode;
	
	
	// **** add player button **** //
	
	// check for button already
	if (document.getElementsByClassName('ytp-button ytp-button-watch-later ytp-button-karaoke').length>0){
		console.log("Button already added");
		return;
	}
	
	// get last player button class
	// youtube class: html5-main-video
	console.log("Getting last button");
	var Buttons = document.getElementsByClassName('ytp-button ytp-button-watch-later');
	var playButton = Buttons[Buttons.length - 1];
	
	// create karaokeButton
	console.log("cloning last button");
	karaokeButton = playButton.cloneNode(true);
	karaokeButton.className = "ytp-button ytp-button-watch-later ytp-button-karaoke";
	
	// add node
	playButton.parentNode.appendChild( karaokeButton );
	console.log("Added karaoke button");
	
	// setup audio routing
	SetupFilter();
	
	karaokeState = 1;
	karaokeStateChange();
	
	// add listener to button
	karaokeButton.addEventListener('click', karaokeStateChange, false);
	karaokeButton.addEventListener('mouseover', karaokeStateOver, false);
	karaokeButton.addEventListener('mouseout', karaokeStateOut, false);
}

function karaokeStateOver()
{
	// add underneath id:movie_player, new child
	var movPlayer = document.getElementById('movie_player');
	// find caption left spacing	
	var leftDist = karaokeButton.getBoundingClientRect().left - movPlayer.getBoundingClientRect().left + 15;
	// find top distance
	var topDist = karaokeButton.getBoundingClientRect().top - 60;
	
	// add caption box to DOM
	var html = '<div class="ytp-tooltip" style="left: ' + leftDist + 'px; top: ' + topDist + 'px; display: block;"><div class="ytp-tooltip-body" style="left: -25.5px;"><span class="ytp-text-tooltip">Karaoke</span></div><div class="ytp-tooltip-arrow"></div></div>';
	
	var div = document.createElement('div');
	div.innerHTML = html;
	while (div.children.length > 0) {
		movPlayer.appendChild(div.children[0]);
	}
}

function karaokeStateOut()
{  
	// remove caption box
	var tooltips = document.getElementsByClassName('ytp-tooltip');
	for (var i=0;i<tooltips.length;i++)
	{ 
		tooltips[i].parentNode.removeChild(tooltips[i]);
	}
}

function karaokeStateChange(){
	
	// turn on/off filters
	if (karaokeState==0){
		console.log("Removing vocals");
		audioSource.disconnect(0);
		if (filtersOn){
			// filter type
			if (filterType==0){
				audioSource.connect(FilterNotch);
				audioSource.connect(FilterBand);
			} else if (filterType==1){
				audioSource.connect(FilterBand);
			} else if (filterType==2){
				audioSource.connect(FilterLP1);
				audioSource.connect(FilterLP2);
			} else if (filterType==3){
				// input to bandpass
				audioSource.connect(FilterLP1);
				
				// input to bandstop
				audioSource.connect(FilterLP2);
				audioSource.connect(FilterHP2);
			}
		} else {
			audioSource.connect(splitter);
		}
		
		karaokeState = 1;
		karaokeButton.className = "ytp-button ytp-button-watch-later ytp-button-karaoke ytp-button-karaoke-on";
		
		// show lyrics div
		if (lyricsShown==0) {
			getLyrics();
		}
		lyricsShown = 1;
		
	} else {
		console.log("Adding in vocals");
		audioSource.disconnect(0);
		audioSource.connect(context.destination);
		
		karaokeState = 0;
		karaokeButton.className = "ytp-button ytp-button-watch-later ytp-button-karaoke";
		
		// hide lyrics div
	}
}

function SetupFilter(){
	// setup audio routing
	try {
		// Fix up for prefixing
		window.AudioContext = window.AudioContext||window.webkitAudioContext;
		context = new AudioContext();
		
		audioSource = context.createMediaElementSource(mediaElement);
		
		// phase inversion filter
		// input -> splitter
		// output -> destination
		splitter = context.createChannelSplitter(2);
		gainL = context.createGain();
		gainR = context.createGain();
		// Gain stages
		gainL.gain.value = 1;
		gainR.gain.value = -1;
		// reconnect outputs
		splitter.connect(gainL, 0);
		splitter.connect(gainR, 1);
		gainL.connect(context.destination);
		gainR.connect(context.destination);
		
		// Create the bandpass filters
		if (filterType==0){	// if - changes filter type
			// inputs -> FilterNotch & FilterBand
			// outputs -> splitter & destination
			
			// Create the bandpass filters
			FilterNotch = context.createBiquadFilter();
			FilterBand  = context.createBiquadFilter();

			// Notch filter
			FilterNotch.type = 6;
			FilterNotch.frequency.value = 500;	// Set cutoff to 440 HZ
			FilterNotch.Q.value = 0.05; 			// Set cutoff to 440 HZ
			// Bandpass filter
			FilterBand.type = 2;
			FilterBand.frequency.value = 500;	// Set cutoff to 440 HZ
			FilterBand.Q.value = 0.38;			// Set cutoff to 440 HZ

			// connect filters
			FilterNotch.connect(context.destination);
			FilterBand.connect(splitter);
		} else if (filterType==1) {
			// subtract band pass from original
			// inputs -> FilterBand
			// outputs -> splitter & destination
			console.log("Filter 1");
			
			FilterBand  = context.createBiquadFilter();
			
			// Bandpass filter
			FilterBand.type = 2;
			FilterBand.frequency.value = 500;	// Set cutoff to 440 HZ
			FilterBand.Q.value = 0.38;
			
			// setup band notch filter
			gainFilter = context.createGain();
			gainFilter.gain.value = -1;
			
			// connect filters
			FilterBand.connect(splitter);
			FilterBand.connect(gainFilter);
			gainFilter.connect(context.destination);
			audioSource.connect(context.destination);
		} else if(filterType==2) {
			// create band pass/stop using two biquads
			// inputs -> FilterLP1 & FilterLP2
			// outputs -> splitter & destinations
			console.log("Filter 2");
			
			// filter cutoff frequencies (Hz)
			var f1 = 150;
			var f2 = 7000;
			
			// Bandpass filter = LP + HP
			FilterLP1 = context.createBiquadFilter();
			FilterLP1.type = 0;
			FilterLP1.frequency.value = f2;
			FilterLP1.Q.value = 1;
			FilterHP1 = context.createBiquadFilter();
			FilterHP1.type = 1;
			FilterHP1.frequency.value = f1;
			FilterHP1.Q.value = 1;
			// Bandstop filter = LP + HP
			FilterLP2 = context.createBiquadFilter();
			FilterLP2.type = 0;
			FilterLP2.frequency.value = f1;
			FilterLP2.Q.value = 1;
			FilterHP2 = context.createBiquadFilter();
			FilterHP2.type = 1;
			FilterHP2.frequency.value = f2;
			FilterHP2.Q.value = 1;
			
			// connect filters
			FilterLP1.connect(FilterHP1);
			FilterHP1.connect(splitter);
			FilterLP2.connect(FilterHP2);
			FilterHP2.connect(context.destination);
		}else if(filterType==3) {
			// create band pass/stop using two cascaded biquads
			// inputs -> FilterLP1 & FilterLP2
			// outputs -> splitter & destinations
			console.log("Filter 3");
			
			// filter cutoff frequencies (Hz)
			var f1 = 200;
			var f2 = 6000;
			
			// Bandpass filter = LP + HP
			FilterLP1 = context.createBiquadFilter();
			FilterLP1.type = "lowpass";
			FilterLP1.frequency.value = f2;
			FilterLP1.Q.value = 1;
			
			FilterLP3 = context.createBiquadFilter();
			FilterLP3.type = "lowpass";
			FilterLP3.frequency.value = f2;
			FilterLP3.Q.value = 1;
			
			FilterHP1 = context.createBiquadFilter();
			FilterHP1.type = "highpass";
			FilterHP1.frequency.value = f1;
			FilterHP1.Q.value = 1;
			
			FilterHP3 = context.createBiquadFilter();
			FilterHP3.type = "highpass";
			FilterHP3.frequency.value = f1;
			FilterHP3.Q.value = 1;
			
			// Bandstop filter = LP + HP
			// blocking out everything!
			FilterLP2 = context.createBiquadFilter();
			FilterLP2.type = "lowpass";
			FilterLP2.frequency.value = f1;
			FilterLP2.Q.value = 1;

			FilterLP4 = context.createBiquadFilter();
			FilterLP4.type = "lowpass";
			FilterLP4.frequency.value = f1;
			FilterLP4.Q.value = 1;
			
			FilterHP2 = context.createBiquadFilter();
			FilterHP2.type = "highpass";
			FilterHP2.frequency.value = f2;
			FilterHP2.Q.value = 1;
			
			FilterHP4 = context.createBiquadFilter();
			FilterHP4.type = "highpass";
			FilterHP4.frequency.value = f2;
			FilterHP4.Q.value = 1;
			
			// connect filters
			FilterLP1.connect(FilterLP3);
			FilterLP3.connect(FilterHP1);
			FilterHP1.connect(FilterHP3);
			FilterHP3.connect(splitter);
			
			FilterLP2.connect(FilterLP4);
			FilterLP4.connect(context.destination);
			FilterHP2.connect(FilterHP4);
			FilterHP4.connect(context.destination);
		}

		audioSource.disconnect(0);
	}
	catch(e) {
		alert('Web Audio API is not supported in this browser');
	}
}

function myjsonpfunction(data){
	console.log("JSON data received");
	alert(data.responseData.results) //showing results data
	$.each(data.responseData.results,function(i,rows){
		alert(rows.url); //showing  results url
	});
}

// **** lyrics functions **** //
function getLyrics() {
	// get video title
	videoTitleDOM = document.getElementById('watch-headline-title').innerHTML;
	videoTitleDOM = videoTitleDOM.replace(/<[^>]*>/g, "").trim();
	
	videoTitle = videoTitleDOM.replace(/\s+/gm, ' ')        // Remove all white spaces with a single space
	.trim()                       // Trim it
	.replace(/( \(.+\))+$/g, '')  // Remove additional info like (video)
	.replace(/( \[.+\])+$/g, '')  // Remove additional info like [video]
	.replace(/-(?=[^\s])/g, '- ') // Change -something to - something, so Google includes it in search
	.trim();                      // Trim it once more.
	
	
	console.log("Video title");
	console.log(videoTitle);
	
	// fetch lyrics
	var lyric_url;
	
	// run google search for top lyrics
	var lyrics_url = 'https://ajax.googleapis.com/ajax/services/search/web?v=1.0&q=site%3Alyrics.wikia.com%22+' + encodeURIComponent(videoTitle) + ' -"Page Ranking Information"';
	console.log(lyrics_url);
	
	var xhr = new XMLHttpRequest();
	
	xhr.open("GET", lyrics_url, true);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			//handle the xhr response here
			if (xhr.status == 200) {
				console.log("Lyric results received");
				var xhrData = jQuery.parseJSON( xhr.responseText );
				// get first result url
				lyric_url = xhrData.responseData.results[0].unescapedUrl;
				console.log(lyric_url);
				
		        if(!lyric_url){
		          console.log("Could not find lyrics");
				  return;
		        }
		        if(lyric_url.lastIndexOf(':')<7){
		          console.log("Could not find lyrics");
				  return;
		        }
				
				// make lyrics div
				// add to top of #watch7-sidebar-contents
				// add iframe, source of lyric_url
				
				lyric_url = lyric_url.replace(/^http:\/\//i, 'https://');
				// var iframeHREF = lyric_url+'?useskin=wikiamobile';
// 				console.log(iframeHREF);
// 				var iframe = document.createElement('iframe');
// 				    iframe.src = iframeHREF;
// 				var sidebar = document.getElementById('watch7-sidebar-contents');
// 				    sidebar.appendChild(iframe);
// 					
// 				// var webview = document.createElement('webview');
// // 					webview.src = iframeHREF;
// // 					webview.width = "300";
// // 					webview.height = "400";
// // 				var sidebar = document.getElementById('watch7-sidebar-contents');
// // 				    sidebar.appendChild(webview);
// 				console.log("webview added");
					
				var lyricXHR = new XMLHttpRequest();

				lyricXHR.open("GET", lyric_url, true);
				lyricXHR.onreadystatechange = function() {
					if (lyricXHR.readyState == 4) {
						//handle the xhr response here
						if (lyricXHR.status == 200) {
							console.log("Lyrics received");
							// console.log(lyricXHR.responseText);
							
							// lyricXHR.responseText.indexOf("<div class=")
							var LyricContent= $(lyricXHR.responseText).find(".lyricbox");
							console.log(LyricContent);
							
				            if(!LyricContent){
			  		          console.log("Could not find lyrics");
			  				  return;
				            }
							
							LyricContent.find('div:first').remove();
							console.log(LyricContent.text());
							console.log(LyricContent);
							console.log(LyricContent[0].innerHTML);
							
							var lyricsDiv = document.createElement('div');
								lyricsDiv.className = 'lyricsBox';
								lyricsDiv.innerHTML = LyricContent[0].innerHTML;
							var sidebar = document.getElementById('watch7-sidebar-contents');
								sidebar.insertBefore(lyricsDiv, sidebar.firstChild);
								// sidebar.appendChild(lyricsDiv);
							// var n = str.indexOf("welcome");
							// var html = $.parseHTML( lyricXHR.responseText );
// 							console.log(html);
							// var object = $('<div/>').html(lyricXHR.responseText).contents();

							// console.log( object.$( "#lyricbox" ) );
						}
					}
				}
				lyricXHR.send();
			}
		}
	}
	xhr.send();
	
	
	// get lyrics content
	
	// need to extract lyricbox
	// or use mobile mode http://lyrics.wikia.com/Cake:Dime?useskin=wikiamobile
	// var xhr = new XMLHttpRequest();
// 	
// 	xhr.open("GET", lyric_url, true);
// 	xhr.onreadystatechange = function() {
// 		if (xhr.readyState == 4) {
// 			//handle the xhr response here
// 			if (xhr.status == 200) {
// 				console.log("Lyric results received");
// 				var xhrData = jQuery.parseJSON( xhr.responseText );
// 				// get first result url
// 				lyric_url = JSONUrl.responseData.results[0].url;
// 				console.log(lyric_url);
// 			}
// 		}
// 	}
// 	xhr.send();
	
	
}

// **** main **** //
console.log("Loading insert");
SetupButton();
console.log("Finished");

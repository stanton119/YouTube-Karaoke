function SetupButton(){
	// get last player button class
	// youtube class: html5-main-video
	var Buttons = document.getElementsByClassName('ytp-button ytp-button-watch-later');
	var playButton = Buttons[Buttons.length - 1];
	
	// create karaokeButton
	console.log("cloning last button");
	karaokeButton = playButton.cloneNode(true);
	if (karaokeState) {
		karaokeButton.className = "ytp-button ytp-button-watch-later ytp-button-karaoke ytp-button-karaoke-on";
	} else {
		karaokeButton.className = "ytp-button ytp-button-watch-later ytp-button-karaoke";
	}
	
	// add node
	playButton.parentNode.appendChild( karaokeButton );
	console.log("Added karaoke button");
	
	// add listener to button
	karaokeButton.addEventListener('click', karaokeStateChange, false);
	karaokeButton.addEventListener('mouseover', karaokeStateOver, false);
	karaokeButton.addEventListener('mouseout', karaokeStateOut, false);
}

function karaokeStateChange(){
	// create eventlisteners for clicking, contents:
	chrome.runtime.sendMessage({greeting: "buttonClick"}, function(response) {
		console.log(response.farewell);
	});
	
	// change css
	if (karaokeState) {
		karaokeState = 0;
		karaokeButton.className = "ytp-button ytp-button-watch-later ytp-button-karaoke";
	} else {
		karaokeState = 1;
		karaokeButton.className = "ytp-button ytp-button-watch-later ytp-button-karaoke ytp-button-karaoke-on";
	}
}

function karaokeStateOver()
{
	// add underneath id:movie_player, new child
	var movPlayer = document.getElementById('movie_player');
	// find caption left spacing	
	var leftDist = karaokeButton.getBoundingClientRect().left - movPlayer.getBoundingClientRect().left + 15;
	// find top distance
	var topDist = karaokeButton.getBoundingClientRect().top - movPlayer.getBoundingClientRect().top;
	
	// add caption box to DOM
	var html = '<div class="ytp-tooltip" style="left: ' + leftDist + 'px; top: ' + topDist + 'px; display: block;"><div class="ytp-tooltip-body" style="left: -25.5px;"><span class="ytp-text-tooltip">Karaoke</span></div><div class="ytp-tooltip-arrow"></div></div>';
	// left shift by half the tooltip box size
	
	var div = document.createElement('div');
	div.innerHTML = html;
	while (div.children.length > 0) {
		movPlayer.appendChild(div.children[0]);
	}
}

function karaokeStateOut()
{  
	// remove caption box
	var tooltips = document.getElementsByClassName('ytp-tooltip');
	for (var i=0;i<tooltips.length;i++)
	{ 
		tooltips[i].parentNode.removeChild(tooltips[i]);
	}
}

// displayButton function
SetupButton();

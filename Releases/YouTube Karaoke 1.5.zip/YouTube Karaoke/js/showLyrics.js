function getPlayerTitle(){
	videoTitleDOM = document.getElementById('watch-headline-title').innerHTML;
	videoTitleDOM = videoTitleDOM.replace(/<[^>]*>/g, "").trim();
	
	videoTitle = videoTitleDOM.replace(/\s+/gm, ' ')        // Remove all white spaces with a single space
	.trim()                       // Trim it
	.replace(/( \(.+\))+$/g, '')  // Remove additional info like (video)
	.replace(/( \[.+\])+$/g, '')  // Remove additional info like [video]
	.replace(/-(?=[^\s])/g, '- ') // Change -something to - something, so Google includes it in search
	.trim();                      // Trim it once more.
	
	return videoTitle;
}

console.log("Video title: " + getPlayerTitle());
getLyricsURL(getPlayerTitle());

// function to get lyric URL
function getLyricsURL(videoTitle) {
	// form google search url
	var google_url = 'https://ajax.googleapis.com/ajax/services/search/web?v=1.0&q=site%3Alyrics.wikia.com%22+' + encodeURIComponent(videoTitle) + ' -"Page Ranking Information"';
	console.log(google_url);
	
	// setup XHR
    var req = new XMLHttpRequest();
    req.open("GET", google_url, true);
    
	req.onreadystatechange = function() {
	    if (req.readyState === 4)
	    {
			try {
				var reqData = jQuery.parseJSON( req.responseText );
				parseLyrics(reqData.responseData.results[0].unescapedUrl);
			} catch(e) {
				errorShow(e);
			};
	    } else {
	    	errorShow;
	    }
	};
	
	req.send(null);
}


// function to parse lyric URL
function parseLyrics (lyricsURL) {
	console.log(lyricsURL);
	
    if(!lyricsURL){
      errorShow();
	  return;
    }
	
	// setup XHR
    var lyricReq = new XMLHttpRequest();
    lyricReq.open("GET", lyricsURL, true);
	lyricReq.onreadystatechange = function() {
	    if (lyricReq.readyState === 4)
	    {
			try {
				// find lyric content
				var lyricContent= $(lyricReq.responseText).find(".lyricbox");
	            if(!lyricContent){
  		          errorShow;
  				  return;
	            }
				// remove extra content
				lyricContent.find('div:first').remove();
				
				// create div
				var lyricDiv = document.createElement('div');
					lyricDiv.className = 'lyricsBox';
					// use innerText to prevent XSS
					lyricDiv.innerText = lyricContent[0].innerText;
					
				// add header at top
				lyricDiv.insertBefore(createLyricHeader(lyricsURL), lyricDiv.firstChild);	
				// insert into page
				insertIntoPage(lyricDiv);
			} catch(e) {
				errorShow(e);
			};
	    } else {
	    	errorShow;
	    }
	};
	
	lyricReq.send(null);
}

// function for lyric header
function createLyricHeader(lyricsURL) {
	// create div
	var lyricHeader = document.createElement('div');
		lyricHeader.className = 'lyricsHeader';
	
	// create links
	lyricHeader.appendChild(sourceLink(lyricsURL));
	lyricHeader.appendChild(document.createTextNode(" ---- "));
	lyricHeader.appendChild(getSearchLinks());
	return lyricHeader;
}

// function for sourceLink
function sourceLink(lyricsURL, sourceText) {
	// parameter defaults
	sourceText = typeof sourceText !== 'undefined' ? sourceText : "From Lyric.Wikia.com";
	lyricsURL = typeof lyricsURL !== 'undefined' ? lyricsURL : "http://lyrics.wikia.com/";
	
	// create links
	var sourceLinkA = document.createElement('a');
	sourceLinkA.appendChild(document.createTextNode(sourceText));
	sourceLinkA.title = sourceText;
	sourceLinkA.className = "lyrics_sourceLink";
	sourceLinkA.href = lyricsURL;
	sourceLinkA.target = "_blank";
	return sourceLinkA;
}

// function for searchLinks
function getSearchLinks(wrongLyrics) {
	// linktext:
	wrongLyrics = typeof wrongLyrics !== 'undefined' ? wrongLyrics : "Wrong lyrics?";
	
	// create links
	var searchLink = "https://www.google.com/?#q=lyrics%20" + encodeURIComponent(getPlayerTitle());
	var searchLinkA = document.createElement('a');
	searchLinkA.appendChild(document.createTextNode(wrongLyrics));
	searchLinkA.title = wrongLyrics;
	searchLinkA.className = "lyrics_searchLink";
	searchLinkA.href = searchLink;
	searchLinkA.target = "_blank";
	return searchLinkA;
}

// function on error calls
function errorShow(e) {
	console.log("Error - could not find lyrics");
	if (e) {
		console.log(e);
	}
	
	// lyric not found dialog
	// create div
	var lyricDiv = document.createElement('div');
		lyricDiv.className = 'lyricsBox lyricsBoxNo';
		// use innerText to prevent XSS
		lyricDiv.innerText = " -- Lyrics not found --";
		
	// create links
	lyricDiv.insertBefore(getSearchLinks("Search again..."), lyricDiv.firstChild);
		
	// insert into page
	insertIntoPage(lyricDiv);
}

// function to insert complete lyric box into page
function insertIntoPage(lyricDiv) {
	var sidebar = document.getElementById('watch7-sidebar-contents');
		sidebar.insertBefore(lyricDiv, sidebar.firstChild); //watch-discussion, watch7-sidebar-contents, switch between above comments vs above related videos
}
// delete lyric nodes

var lyricsBox = document.getElementsByClassName('lyricsBox')[0];

lyricsBox.parentNode.removeChild(lyricsBox);
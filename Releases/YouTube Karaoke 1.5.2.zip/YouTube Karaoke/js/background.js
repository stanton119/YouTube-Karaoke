chrome.tabs.onCreated.addListener(function(tab) {
	// on new lyrics, assume off by default
	karaoke_enabled[tab.id] = false;
	karaoke_enabled_url[tab.id] = "";
});
chrome.tabs.onUpdated.addListener(function(tab_id, change_info, updated_tab) {	
	// onUpdated
	if (isYoutubeTab(updated_tab)) {
		console.log(updated_tab.id + " tab is youtube");
		console.log(updated_tab.id + " is switched to " + isLyricsEnabled(tab_id));
		
		if (!shownAlready(updated_tab)) {
			//showIcon(updated_lyrics.id);
			console.log("Showing button");
			displayButton(updated_tab.id);
			filterSetup(updated_tab);
			updateURLCheck(updated_tab);
			if (isLyricsEnabled(tab_id)) {
				// buttonOn(updated_tab.id);
				// show lyrics
				console.log("Showing lyrics");
				filterOn(updated_tab);
				showLyrics(updated_tab);
				// vocal filter already on
			}
		}
	}
});

karaoke_enabled = [];

function isYoutubeTab(tab) {
	// true if video player only
	return (tab.url.indexOf('youtube.com/watch') > -1);
}
karaoke_enabled_url = [];
function shownAlready(tab) {
	// true if show tab has completed on current url
	// if current url = url of tab shown
	return (tab.url == karaoke_enabled_url[tab.id]);
}
function showIcon(tab_id) {
	chrome.pageAction.show(tab_id);
}
function displayButton(tab_id) {
	if (isLyricsEnabled(tab_id)) {
		chrome.tabs.executeScript(tab_id, {code: 'var karaokeState = 1;'});
	} else {
		chrome.tabs.executeScript(tab_id, {code: 'var karaokeState = 0;'});
	}
	chrome.tabs.executeScript(tab_id, {file: "js/displayButton.js"});
}
function buttonOn(tab_id) {
	chrome.tabs.executeScript(tab_id, {file: "js/buttonOn.js"});
}
function updateURLCheck(updated_tab) {
	karaoke_enabled_url[updated_tab.id] = updated_tab.url;
}
function showLyrics(updated_tab) {
	chrome.tabs.executeScript(updated_tab.id, {file: "js/showLyrics.js"}, function(){
		// callback to show errors
		if (chrome.runtime.lastError) {
            console.error(chrome.runtime.lastError.message);
        }
	});
}
function hideLyrics(updated_tab) {
	chrome.tabs.executeScript(updated_tab.id, {file: "js/hideLyrics.js"}, function(){
		// callback to show errors
		if (chrome.runtime.lastError) {
            console.error(chrome.runtime.lastError.message);
        }
	});
}
function filterSetup(updated_tab) {
	if (isLyricsEnabled(updated_tab.id)) {
		chrome.tabs.executeScript(updated_tab.id, {code: 'var filterState = 1;'});
	} else {
		chrome.tabs.executeScript(updated_tab.id, {code: 'var filterState = 0;'});
	}
	chrome.tabs.executeScript(updated_tab.id, {file: "js/vocalFilter.js"}, function(){
		// callback to show errors
		if (chrome.runtime.lastError) {
            console.error(chrome.runtime.lastError.message);
        }
	});
}
function filterOn(updated_tab) {	
	console.log("filter on");
	chrome.tabs.sendMessage(updated_tab.id, {greeting: "filterOn"}, function(response) {
		// console.log(response.farewell);
	});
}
function filterOff(updated_tab) {
	chrome.tabs.sendMessage(updated_tab.id, {greeting: "filterOff"}, function(response) {
		// console.log(response.farewell);
	});
}
function isLyricsEnabled(tab_id) {
	if(typeof karaoke_enabled[tab_id] === 'undefined'){
		karaoke_enabled[tab_id] = 0;
	}
	return karaoke_enabled[tab_id];
}


// event listeners for button change
chrome.runtime.onMessage.addListener(
	function(request, sender, sendResponse) {
		if (request.greeting == "buttonClick") {
			karaoke_enabled[sender.tab.id] = !karaoke_enabled[sender.tab.id];
			console.log("Turning on/off: " + karaoke_enabled[sender.tab.id]);
			
			if (isLyricsEnabled(sender.tab.id)){
				showLyrics(sender.tab);
				filterOn(sender.tab);
			} else {
				hideLyrics(sender.tab);
				filterOff(sender.tab);
			}
		}
	}
);




// Check whether new version is installed
chrome.runtime.onInstalled.addListener(function(details){
    if(details.reason == "install"){
        console.log("First time install, show playlist");
		// new tab with youtube playlist
		chrome.tabs.create({url: "https://www.youtube.com/playlist?list=PLniGrGQu6vfniYxthYMMRChuN1pacWbNX"});
    }else if(details.reason == "update"){
        var thisVersion = chrome.runtime.getManifest().version;
        console.log("Updated from " + details.previousVersion + " to " + thisVersion + "!");
    }
});